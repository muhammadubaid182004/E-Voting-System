from flask import Flask, render_template, request, redirect, url_for, session, flash
import pymysql

app = Flask(__name__)
app.secret_key = 'hello there'

# MySQL Configuration
db_host = 'localhost'
db_user = 'root'
db_password = '2004'
db_name = 'e_voting'

# Function to get database connection
def get_db_connection():
    return pymysql.connect(
        host=db_host, 
        user=db_user, 
        password=db_password, 
        database=db_name, 
        cursorclass=pymysql.cursors.DictCursor
    )

# Function to fetch top candidates from voting_history
def get_top_candidates():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Query to fetch top candidates with their vote counts
        cursor.execute("""
            SELECT c_name AS candidate_name, COUNT(*) AS vote_count
            FROM voting_history
            GROUP BY c_name
            ORDER BY vote_count DESC
            LIMIT 3
        """)
        top_candidates = cursor.fetchall()

        cursor.close()
        conn.close()

        return top_candidates
    except pymysql.Error as e:
        print(f"An error occurred while fetching top candidates: {e}")
        return None

@app.route('/')
def index():
    return render_template('about.html')

@app.route('/login.html', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if username and password exist in the database
        cursor.execute("SELECT p_username, p_password FROM public_password WHERE p_username=%s AND p_password=%s", (username, password))
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()

        if user:
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html')
    return redirect(url_for('login'))

@app.route('/candidates')
def candidates():
    if 'username' in session:
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT c.c_name, c.political_party, cp.ink_mark
                FROM candidate c
                JOIN candidate_password cp ON c.candidate_NIC = cp.candidate_NIC
            """)
            data = cursor.fetchall()
            
            cursor.close()
            conn.close()
            
            vote_recorded = session.pop('vote_recorded', False)
            
            return render_template('index.html', data=data, vote_recorded=vote_recorded)
        
        except pymysql.Error as e:
            flash(f'An error occurred: {e}')
            return redirect(url_for('login'))
    
    return redirect(url_for('login'))



@app.route('/vote', methods=['POST'])
def vote():
    if 'username' in session:
        candidate_name = request.form.get('candidate')
        voter_username = session['username']

        if not candidate_name:
            flash('Please select a candidate to vote.', 'error')
            return redirect(url_for('candidates'))

        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            # Fetch public_NIC and p_name from public table based on username
            cursor.execute("SELECT public_NIC, p_name FROM public WHERE public_NIC = (SELECT public_NIC from public_password where p_username = %s)", (voter_username,))
            user_info = cursor.fetchone()

            if user_info:
                public_NIC, p_name = user_info['public_NIC'], user_info['p_name']

                # Check if user has already voted
                cursor.execute("SELECT * FROM voting_history WHERE public_NIC = %s", (public_NIC,))
                existing_vote = cursor.fetchone()

                if existing_vote:
                    flash('Dear Voter We Are Sorry You Cannot Cast Your Vote, You have already voted.', 'error')
                else:
                    # Fetch political party name based on candidate_name
                    cursor.execute("SELECT political_party FROM candidate WHERE c_name = %s", (candidate_name,))
                    political_party = cursor.fetchone()

                    if political_party:
                        political_party = political_party['political_party']

                        # Insert into voting_history table
                        cursor.execute("INSERT INTO voting_history (public_NIC, p_name, c_name, political_party) VALUES (%s, %s, %s, %s)",
                                       (public_NIC, p_name, candidate_name, political_party))
                        conn.commit()
                        session['vote_recorded'] = True  # Set flag in session
                        flash('Your vote has been recorded. Thank you!', 'success')
                    else:
                        flash('Political party information not found for the selected candidate.', 'error')
            else:
                flash('User information not found.', 'error')
        except pymysql.Error as e:
            conn.rollback()
            flash(f'An error occurred: {e}', 'error')
        finally:
            cursor.close()
            conn.close()

        return redirect(url_for('dashboard'))  # Redirect to dashboard regardless of voting status
    return redirect(url_for('login'))

@app.route('/update')
def update():
    message = request.args.get('message', '')
    return render_template('update.html', message=message)

@app.route('/update-password', methods=['POST'])
def update_password():
    cnic = request.form['cnic']
    old_password = request.form['old_password']
    new_password = request.form['new_password']

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if CNIC and old password match
        cursor.execute("SELECT * FROM public_password WHERE public_NIC = %s AND p_password = %s", (cnic, old_password))
        user = cursor.fetchone()

        if user:
            # Update the password
            cursor.execute("UPDATE public_password SET p_password = %s WHERE public_NIC = %s", (new_password, cnic))
            conn.commit()
            return redirect(url_for('update', message="Password updated successfully."))
        else:
            return redirect(url_for('update', message="CNIC or old password is incorrect. Please try again."))
   
    except pymysql.MySQLError as e:
        print(f"Database error: {e}")
        conn.rollback()
        return redirect(url_for('update', message="Error updating password. Please try again later."))
   
    finally:
        cursor.close()
        conn.close()

@app.route('/delete')
def delete():
    message = request.args.get('message', '')
    return render_template('delete.html', message=message)

@app.route('/delete-contact', methods=['POST'])
def delete_contact():
    cnic = request.form['cnic']
    phone_number = request.form['phone_number']

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if CNIC exists in public_contactno and if the phone number exists exactly twice
        cursor.execute("SELECT * FROM public_contactno WHERE public_NIC = %s AND p_contactno = %s", (cnic, phone_number))
        contact_info = cursor.fetchone()

        if contact_info:
            cursor.execute("SELECT COUNT(p_contactno) FROM public_contactno WHERE public_NIC = %s", (cnic,))
            count = cursor.fetchone()
            if count.get('COUNT(p_contactno)') == 2:
                # Delete the record containing the phone number
                cursor.execute("DELETE FROM public_contactno WHERE public_NIC = %s AND p_contactno = %s", (cnic, phone_number))
                conn.commit()
                return redirect(url_for('delete', message="Phone number deleted successfully."))
            else:
                return redirect(url_for('delete', message="The phone number must exist exactly twice to be deleted."))
        else:
            return redirect(url_for('delete', message="CNIC is incorrect. Please try again."))

    except pymysql.MySQLError as e:
        print(f"Database error: {e}")
        conn.rollback()
        return redirect(url_for('delete', message="Error deleting phone number. Please try again later."))
   
    finally:
        cursor.close()
        conn.close()

@app.route('/results')
def results():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Query to get top 3 candidates based on vote counts
        cursor.execute("""
            SELECT c.c_name AS candidate_name, c.political_party, COUNT(v.public_NIC) AS vote_count
            FROM candidate c
            LEFT JOIN voting_history v ON c.c_name = v.c_name
            GROUP BY c.c_name, c.political_party
            ORDER BY vote_count DESC
            LIMIT 3
        """)

        top_candidates = cursor.fetchall()
        cursor.close()
        conn.close()

        # Determine result status
        if len(top_candidates) > 1 and top_candidates[0]['vote_count'] == 0 and top_candidates[1]['vote_count'] == 0 and top_candidates[2]['vote_count']:
            result_status = "No votes have been cast yet."
        elif len(top_candidates) > 1 and top_candidates[0]['vote_count'] == top_candidates[1]['vote_count']:
            result_status = f"Tied - No Result (Top Candidates: {top_candidates[0]['vote_count']} votes each)"
        else:
            result_status = f"The Winner is {top_candidates[0]['candidate_name']} From {top_candidates[0]['political_party']} with {top_candidates[0]['vote_count']} votes"

        return render_template('results.html', top_candidates=top_candidates, result_status=result_status)

    except pymysql.Error as e:
        flash(f'An error occurred: {e}')
        return redirect(url_for('dashboard'))


if __name__ == '__main__':
    app.run(debug=True)
    